
    // typing text animation script
    var typed = new Typed(".typing", {
        strings: ["Investigación", "Expectativas", "Patrones"],
        typeSpeed: 100,
        backSpeed: 30,
        loop: true
    });

   


   